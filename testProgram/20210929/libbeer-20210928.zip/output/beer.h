#include <arpa/inet.h>
#include <fcntl.h>
#include <beer_sock.h>

class Beer {
};
